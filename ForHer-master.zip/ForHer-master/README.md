# ForHer
ForHer is a women safety app where women can send their current location to their guardians and Police when they feel unsafe and in danger.
They just need to open the app and send the alert message to their family or friends just by shaking the phone or clicking the send location button.
There is a seperate Login page for police where they can see the recent requests which contain the user's image, name, location and contact number. Police will get redirected to google maps just by clicking the request.
